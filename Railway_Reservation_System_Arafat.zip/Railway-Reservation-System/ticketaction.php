
<!DOCTYPE HTML>
<html>
    <head>
            <title>Reservation</title>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="css/index.css"/>
            <link rel="stylesheet" type="text/css" href="css/slide.css"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="js/main.js"></script>
            
    </head>
    <body>
        <center>
    
        <!-- <h1>Reservation</h1> -->
       <!--  <img src="img/bg2.jpg" width="1900" height="80"> -->
        </center>
        <div class="nav">
        <nav>
        <ul>
               <!--  <li><a>Reservation</a></li> -->
              
                <?php session_start();

                include('index.php');
          ?>
                
        </ul> 
        </nav>
        </div>
<?php
include("header");
if(isset($_GET['submit']))
{
        include("checkdb.php");
        $source=$_GET['source'];
        $destination=$_GET['destination'];
        $tier=$_GET['tier'];
        $date=$_GET['date'];
        $adults=$_GET['adults'];
        $childs=$_GET['childs'];
        //$cust_id=$_GET['cust_id'];
        $AMumbai=800;
        $CMumbai=500;
        $ADelhi=1000;
        $CDelhi=700;
        $ALucknow=800;
        $CLucknow=500;
        $AKolkata=500;
        $CKolkata=800;
        $Cwed=500;
        $price=0;
       
         
        if($destination=='Mumbai')
        {
            $price=$AMumbai*$adults+$CMumbai*$childs;
        }
       elseif ($destination== 'Delhi')
       {
        $price=$ADelhi*$adults+$CDelhi*$childs;
        
        }
       elseif ($destination== 'Lucknow')
       {
        $price=$ALucknow*$adults+$CLucknow*$childs;
       }
        elseif ($destination== 'Kolkata')
       {
        $price=$AKolkata*$CKolkata;
       }
      
       $email=$_SESSION['user_info'];
       
        $sql= "INSERT INTO tickets (source,destination,tier,date,adults,childs,price,email) values ('$source','$destination','$tier','$date','$adults','$childs','$price','$email')";
        
        if($conn->query($sql)===TRUE)
        {
            echo "";
        }
        else
        {
            echo $conn->error;
        }
        
       }
       
?>
<div class="card" >
<div align="center" style="width:870px;margin:0 auto;">
        <div class="card" >
        <h2> congratulation!!!</h2>
   <h4> Your Tickets are booked by email <?php echo $_SESSION['user_info']; ?>....!!!!</h4>
     <h4>You Paid <?php echo $price; ?></h4>
</div>    
</div>



<hr>
              <p style="font-size: 15px; padding-left: 39%;"><br><a href="subscribe.html"></a></p>
              <center>
                
                <h3 style="color: red; font-size:20px;">Thank You, Visit again !!!</h3>
              <main>
                <h4><b>Contact Me!</b></h4>
                <address>
                    <div>Mumbai, Maharashtra</div>
                    <div>Phone: <a href="tel:+919990982934">+91-9990982934</a></div>
                    <div style="margin-bottom: 80px;">Email: <a href="mailto:Vipkhan920@gmail.com">Vipkhan920@gmail.com</a></div>
                    
                </address>
            </main>
          </center>
              <footer>
            &copy; 2019 Indian Railways,All Right Reserved .
    
            </footer>
    </body>
</html>
