<?php 
require_once('database/Database.php');
$sql = "SELECT *
		FROM destination;
";

$destinations = $db->getRows($sql);

$db->Disconnect();

