<?php 
require_once('database/Database.php');
$sql = "SELECT *
		FROM origin;
";

$origins = $db->getRows($sql);

$db->Disconnect();

