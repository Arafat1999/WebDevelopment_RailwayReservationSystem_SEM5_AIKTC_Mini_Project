# Railway-Reservation-System-PHP
Designed a Railway ticket booking, reservation and cancellation system for users that wish to
travel via the Indian Railways.
Technologies used: HTML, PHP, Javascript, MySQL database.
