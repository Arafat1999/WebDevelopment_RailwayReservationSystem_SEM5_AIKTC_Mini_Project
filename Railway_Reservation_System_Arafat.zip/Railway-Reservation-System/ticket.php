<HTML>
<HEAD>
<TITLE>Indian Railways</TITLE>
<style type="text/css">
@import url(style.css);
#logo	{ 
	border-radius: 25px;
    border: 1px solid blue; 
    width: 100px;
    height: 100px; 
}
*	{
	color: black;
}
html { 
  background: url(img/bg7.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
#main	{
		width:700px;
		height: 400px;
		margin: 0 auto;
		margin-top: 30px;
		color:black;
		border-radius: 25px;
  		padding-top: 10px;
    	padding-right: 10px;
    	padding-bottom: 10px;
    	padding-left: 10px;
    	background-color: rgba(0,0,0,0.3);
	}
  .card{
    background-color:lightblue;
    width:40%;
    border:solid black;
  }
</style>
</HEAD>
    
        
        <center>
       <!-- <h1>Reservation </h1> -->
        <!-- <img src="img/bg2.jpg" width="1900" height="80"> -->
        </center>
        <div class="nav">
        <nav>
        <ul>
            

              <?php
              //include("header.php");
              include("index.php");
              ?>
        </ul> 
        </nav>
        </div>
        <br>
        <!-- <marquee> Hurry Up !!!!!!,,, don't miss out the opportunity to visit this Water Park / Adventre Park in Mumbai......</marquee> --->
        <br>
        
        <div align="center" style="width:870px;margin:0 auto;">
        <div class="card" >
        <h3 style="color:red"> Book Your Tickets !</h3>
   
     
    <form method="GET" style="border:2px solid #ccc" action="ticketaction.php">
    <div class="drop1"> 
    <label for="select" class="label" style="color:black">Select Source : </label>
    <select name="source" style="color:black;">
             <option value="Delhi">Delhi</option>
             <option value="Kolkata">Kolkata</option>
             <option value="Mumbai">Mumbai</option>
             <option value="Lucknow">Lucknow</option>

    </select>
    </div>

    <form method="GET" style="border:2px solid #ccc" action="ticketaction.php">
    <div class="drop1"style="color:black;">
    <label for="select" class="label" style="color:black;">Select Destination : </label>
    <select name="destination"style="color:black;">
             <option value="Delhi">Delhi</option>
             <option value="Kolkata">Lucknow</option>
             <option value="Mumbai">Kolkata</option>
             <option value="Lucknow">Mumbai</option>

    </select>
    </div>


    <div class="ticket"style="color:black;">
    <div class="drop4">
    <label for="select" class="label"style="color:black;">Select Tier : </label>
    <select name="tier"style="color:black;">
             <option value="1 Tier">1 Tier  </option>
             <option value="2 Tier">2 Tier</option>
             <option value="3 Tier">3 Tier</option>
             <option value="4 Tier">4 Tier</option>
    </select>
    </div>

    <br>

    <div class="date1">
    <label for="date" style="color:black;"style="color:black;">Select Date : </label>
    <input type="date" name="date" style="color:black;" required><br>
    </div>
    <br>
    <div class="drop2">
    <label for="adults" class="label" style="color:black;">No of Adults : </label>
    <input class="adults" type="number" value="0" name="adults" min="1" max="100" style="color:black;"required>
    </div>
    <br>
    <div class="drop3">
    <label for="childs"style="color:black;">No of Childs : </label>
    <input class="childs" type="number" value="0" name="childs" min="0" max="100" style="color:black;"required>

    </div>
   <input type="submit" value="Book" name="submit" id="submit"style="color:black;">
</form>
</div>
</div>

              <center>
                <!-- <h8 style="color: red; font-size:20px;">We are Happy to Help You !!!</h8><br> -->
                <!-- <b><h8 style="color: red; font-size:20px;">Thank You, Visit again !!!</h8><b> -->
              <main>
              <!-- 
                <h4><b>Contact Me!</b></h4>
                <adress>
                    <div style="color:red; font-size:25px;">Mumbai, Maharashtra</div> 
                    <div>Phone: <a href="tel:+919990982934">+91-9990982934</a></div>
                    <div style="margin-bottom: 80px;">Email: <a href="mailto:arafathonpode@gmail.com">arafathonpode@gmail.com</a></div>
                    -->
                </adress>
            </main>
          </center>
              <footer>
            <p> 2019 IndianRailways, All Right Reserved . <p>
    
            </footer>
    </body>
</html>
