<HTML>
<HEAD>
<TITLE>Indian Railways</TITLE>
<style type="text/css">
@import url(style.css);
#logo	{ 
	border-radius: 25px;
    border: 1px solid blue; 
    width: 100px;
    height: 100px; 
}
*	{
	color: black;
}
html { 
  background: url(img/bg7.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
#main	{
		width:700px;
		height: 400px;
		margin: 0 auto;
		margin-top: 30px;
		color:black;
		border-radius: 25px;
  		padding-top: 10px;
    	padding-right: 10px;
    	padding-bottom: 10px;
    	padding-left: 10px;
    	background-color: rgba(0,0,0,0.3);
	}
  .card{
    background-color:lightblue;
    width:40%;
    border:solid black;
  }
</style>
</HEAD>
    


<?php
 include("header2.php");
session_start();

if(isset($_SESSION['user_info']))
  echo '<h3 align="center"><a href="ticket.php"></a></h3>';
else
  echo '<h3 align="center"><a href="register.php">Please register/login before booking</a></h3>';


$con=mysqli_connect("localhost","arafat","arafat","railway");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$curremail=$_SESSION['user_info'];
$result = mysqli_query($con,"select * from tickets where email='$curremail'");

echo "<table border='1'>
<tr>
<th>PNR</th>
<th>Source</th>
<th>Destination</th>
<th>Tier</th>
<th>Adults</th>
<th>Childs</th>
<th>Price</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['pnr'] . "</td>";
echo "<td>" . $row['source'] . "</td>";
echo "<td>" . $row['destination'] . "</td>";
echo "<td>" . $row['tier'] . "</td>";
echo "<td>" . $row['adults'] . "</td>";
echo "<td>" . $row['childs'] . "</td>";
echo "<td>" . $row['price'] . "</td>";

echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>